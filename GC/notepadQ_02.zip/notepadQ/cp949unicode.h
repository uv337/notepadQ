#ifndef CP949UNICODE_H
#define CP949UNICODE_H

#include<map>



#endif // CP949UNICODE_H
