Test Hangul editor  for  broken characters when Linux,MSwindows , utf-8, euc-kr  
Or 
Text Editor programing  sample source cod  on c++ bulid ( gcc 64bit, QT creator,cmake)

 한글 인코딩시 깨짐문자들을 정상적으로 불러오기위한 테스트를 포함하는 간단한  텍스트 편집기를 보여주는 c++ 샘플소스 프로그래밍입니다.

README.md  by notepadQ 0.1 nightly (build unbuntu20LTS,QT creator) 20210926


[build]
> cmake  ./
>make
